package middleware

import (
	"compress/gzip"
	"io"
	"net/http"
	"strings"
)

type gzipMiddleware struct {
	wrapped    http.Handler
	exceptions []string
}

// NewGzip creates a middleware that gzips responses
// for clients that support it.
func NewGzip(exceptions []string, wrapped http.Handler) http.Handler {
	if wrapped == nil {
		wrapped = http.DefaultServeMux
	}
	if exceptions == nil {
		exceptions = make([]string, 0)
	}
	return &gzipMiddleware{exceptions: exceptions, wrapped: wrapped}
}

func (mw gzipMiddleware) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	for _, e := range mw.exceptions {
		if strings.HasPrefix(r.URL.Path, e) {
			mw.wrapped.ServeHTTP(w, r)
			return
		}
	}

	if !strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
		mw.wrapped.ServeHTTP(w, r)
		return
	}
	w.Header().Add("Content-Encoding", "gzip")
	gzw := gzip.NewWriter(w)
	defer gzw.Close()
	grw := gzipResponseWriter{w, gzw}
	mw.wrapped.ServeHTTP(grw, r)
}

type gzipResponseWriter struct {
	http.ResponseWriter
	io.Writer
}

func (grw gzipResponseWriter) Write(data []byte) (int, error) {
	return grw.Writer.Write(data)
}
