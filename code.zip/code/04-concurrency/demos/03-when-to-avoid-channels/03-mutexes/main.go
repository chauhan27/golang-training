package main

import "sync"

func main() {

}

type User struct {
	Username string
}

var users = make([]User, 0)
var m = sync.RWMutex{}

func getAll() []User {
	m.RLock()
	defer m.RUnlock()
	return users
}

func add(username string) User {
	m.Lock()
	defer m.Unlock()

	u := User{username}
	users = append(users, u)
	return u
}
