package demo

func Add(l, r int) int {
	return l + r
}

func Sub(l, r int) int {
	return l - r
}
