package demo

func Add(l, r int) int {
	return l + r
}

func sub(l, r int) int {
	return l - r
}
