package lab

import (
	"testing"
)

// TIOBE rankings for a recent month
var toMarshal = map[string]int{
	"C":                 1,
	"Java":              2,
	"Python":            3,
	"C++":               4,
	"C#":                5,
	"Visual Basic":      6,
	"PHP":               7,
	"R":                 8,
	"Groovy":            9,
	"Assembly Language": 10,
	"Go":                14,
}

func BenchmarkMarshal(b *testing.B) {

}

func BenchmarkEncode(b *testing.B) {

}
