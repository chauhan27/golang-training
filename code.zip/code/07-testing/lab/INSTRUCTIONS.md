# Testing

Create two benchmark tests that compare the performance of the `encoding/json` package's Marshal function with Encoders.


* The first benchmark test should marshal the `toMarshal` object into a JSON representation
    * the benchmark should capture the Marshal() call and the writing of that result to a `bytes.Buffer`
    * Note: the buffer can be shared between tests, but should be reset after each iteration.
    * Note: errors should be ignored
* The second benchmark test should create a json.Encoder and use it's Encode method to create the JSON representation
    * Only the Encode() method call should be included in the benchmark
    * Use a shared `bytes.Buffer` to capture the result
    * Note: the buffer should be reset after each iteration.
    * Note: errors should be ignored
