package main

import (
	"io"
	"log"
	"net/http"
	"os"
	"sync"
)

func main() {
	// generate CPU profile
	f, err := os.Create("trace.out")
	if err != nil {
		log.Panic(err)
	}
	defer f.Close()

	wg := new(sync.WaitGroup)
	wg.Add(1)
	go func() {
		resp, err := http.Get("http://localhost:3000/debug/pprof/trace?seconds=5")
		if err != nil {
			log.Fatal(err)
		}
		_, err = io.Copy(f, resp.Body)
		if err != nil {
			log.Fatal(err)
		}
		wg.Done()
	}()

	for i := 0; i < 100; i++ {
		go http.Get("http://localhost:3000/wc/1")
	}
	wg.Wait()

}
