package main

import (
	"testing"
)

func TestApp(t *testing.T) {
	main()
}
