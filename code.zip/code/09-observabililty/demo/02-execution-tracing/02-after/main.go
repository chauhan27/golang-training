package main

import (
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"os"
	"runtime/trace"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	// fileName = "./sample.csv"
	fileName = "./bald-mountain_co.csv"
)

type Record struct {
	Time time.Time
	Temp int
}

type Result struct {
	Day     string
	MinTemp int
	AvgTemp int
	MaxTemp int
}

var (
	rawRecordCh = make(chan []string)
	recordCh    = make(chan Record)
	errorCh     = make(chan error)
)

func main() {
	traceFile, err := os.Create("./trace2.out")
	if err != nil {
		log.Fatal(err)
	}
	defer traceFile.Close()
	trace.Start(traceFile)
	defer trace.Stop()
	f, err := os.Open(fileName)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()

	ctx, task := trace.NewTask(context.Background(), "Process 01-01-2019")
	defer task.End()

	r := csv.NewReader(f)
	_, err = r.Read() // read headers from file and throw away
	if err != nil {
		log.Fatal(err)
	}

	go processCSV(ctx, rawRecordCh, recordCh, errorCh)
	resultCh := processRecords(ctx, recordCh)

	go func(errorCh <-chan error) {
		for range errorCh {
			// no-op, just drain channel
		}
	}(errorCh)

	for {
		rawRecord, err := r.Read()
		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}
			errorCh <- err
			continue
		}
		if strings.HasPrefix(rawRecord[timeColumnIndex], "2019-01-01") {
			trace.Log(ctx, "2019-01-01", "Raw record found")
		}
		rawRecordCh <- rawRecord
	}
	close(rawRecordCh)

	results := make(Results, 0)
	for r := range resultCh {
		results = append(results, r)
	}
	sort.Sort(results)
}

func processCSV(ctx context.Context, rawRecordCh <-chan []string, recordCh chan<- Record, errorCh chan<- error) {
	wg := new(sync.WaitGroup)
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go createRecords(ctx, rawRecordCh, recordCh, errorCh, wg)
	}
	go func(wg *sync.WaitGroup) {
		wg.Wait()
		close(recordCh)
	}(wg)
}

const (
	timeStampFormat = "2006-01-02T15:04:05"
	timeColumnIndex = 1
	tempColumnIndex = 43
)

func createRecords(ctx context.Context, in <-chan []string, out chan<- Record, errCh chan<- error, wg *sync.WaitGroup) {
	for rawRecord := range in {
		if strings.HasPrefix(rawRecord[timeColumnIndex], "2019-01-01") {
			defer trace.StartRegion(ctx, "createRecords").End()
		}
		t, err := time.Parse(timeStampFormat, rawRecord[timeColumnIndex])
		if err != nil {
			errCh <- fmt.Errorf("Failed to parse time for raw value: %v.\n%w", rawRecord[timeColumnIndex], err)
			continue
		}
		temp, err := strconv.Atoi(rawRecord[tempColumnIndex])
		if err != nil {
			errCh <- fmt.Errorf("Failed to parse Temp for raw value: %v\n %w", rawRecord[tempColumnIndex], err)
			continue
		}
		out <- Record{Time: t, Temp: temp}
	}
	wg.Done()
}

func processRecords(ctx context.Context, recordCh <-chan Record) <-chan Result {
	resultCh := make(chan Result)
	go func() {
		dayChannels := make(map[string]chan Record)
		wg := new(sync.WaitGroup)
		for r := range recordCh {
			dayString := r.Time.Format("2006-01-02")
			if _, ok := dayChannels[dayString]; !ok {
				wg.Add(1)
				dayChannels[dayString] = make(chan Record)
				go processDay(ctx, dayString, dayChannels[dayString], resultCh, wg)
			}
			dayChannels[dayString] <- r
		}
		for _, ch := range dayChannels {
			close(ch)
		}
		wg.Wait()
		close(resultCh)
	}()
	return resultCh
}

func processDay(ctx context.Context, day string, in <-chan Record, out chan<- Result, wg *sync.WaitGroup) {
	if day == "2019-01-01" {
		defer trace.StartRegion(ctx, "processDay").End()
	}
	records := make([]Record, 0)
	for record := range in {
		records = append(records, record)
	}

	minTemp, maxTemp, avgTemp := math.MaxInt16, math.MinInt16, 0

	for _, r := range records {
		if r.Temp < minTemp {
			minTemp = r.Temp
		}
		if maxTemp < r.Temp {
			maxTemp = r.Temp
		}
		avgTemp += r.Temp
	}
	avgTemp /= len(records)

	out <- Result{Day: day, MinTemp: minTemp, MaxTemp: maxTemp, AvgTemp: avgTemp}

	wg.Done()
}
