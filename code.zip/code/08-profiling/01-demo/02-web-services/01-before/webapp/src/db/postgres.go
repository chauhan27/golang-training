package db

import (
	"database/sql"
	"fmt"
	"sync"
	"time"

	// load the PostgreSQL driver
	_ "github.com/lib/pq"
)

const (
	// TimeLayoutTimestamp is the layout that should be used when parsing Timestamps that are returned from Postgres queries
	TimeLayoutTimestamp = "2006-01-02T15:04:05Z"
)

var (
	db *sql.DB
	m  sync.Mutex
)

// GetDB returns a *sql.DB object that can be used to interact with the database
func GetDB() (*sql.DB, error) {
	m.Lock()
	var err error
	if db == nil {
		db, err = sql.Open("postgres",
			"user=postgres password=postgres dbname=postgres host=db sslmode=disable")
		if err != nil {
			return nil, fmt.Errorf("could not open connection to database: %v", err)
		}
	}
	m.Unlock()
	return db, nil
}

// FromTimestamp takes a timestamp from the database and attempts to convert it to a time.Time.
func FromTimestamp(timestamp string) (time.Time, error) {
	return time.Parse(TimeLayoutTimestamp, timestamp)
}

// ToTimestamp takes a time and converts it to a format that the database will understand.
func ToTimestamp(t time.Time) string {
	return t.Format(TimeLayoutTimestamp)
}
