package main

import (
	"log"
	"net/http"

	"github.com/silvercloudtraining/webapp/admin"

	"github.com/silvercloudtraining/webapp/wc"

	"github.com/silvercloudtraining/webapp/db"

	"github.com/silvercloudtraining/webapp/routes"
	"github.com/silvercloudtraining/webapp/view"
)

func main() {
	database, err := db.GetDB()
	if err != nil {
		log.Fatalf("could not connect to database: %v", err)
	}
	wc.SetDB(database)
	admin.SetDB(database)

	view.RegisterStaticHandlers()
	routes.Register()

	log.Fatal(http.ListenAndServe(":3000", nil))
}
