package alog

import (
	"io"
	"os"
	"testing"
)

const testMessage = "test message"

func TestWrite(t *testing.T) {
	destination = os.TempDir() + `\\test.log`

	// cleanup before test
	os.Remove(destination)

	Run(destination)

	lw.Write([]byte(testMessage))

	f, err := os.Open(destination)
	if err != nil {
		t.Fatal(err)
	}
	content, err := io.ReadAll(f)
	if err != nil {
		t.Fatal(err)
	}
	if string(content) != testMessage {
		t.Fail()
	}
}
