package main

import (
	"fmt"
	"runtime"
	"sync"
)

func main() {
	wg := new(sync.WaitGroup)
	for i := 0; i <= 10; i++ {
		wg.Add(1)
		go func(i int) {
			for j := 0; j < 5; j++ {
				fmt.Println(i)
				runtime.Gosched()
			}
			wg.Done()
		}(i)
	}

	wg.Wait()
}
