package main

import (
	"fmt"
	"runtime"
	"sync"
)

func main() {
	// gc()
	// setfinalizer()
}

func gc() {
	wg := new(sync.WaitGroup)
	for i := 0; i < 500; i++ {
		wg.Add(1)
		go func() interface{} {
			defer wg.Done()
			return make(map[string]int, 100)
		}()
	}
	wg.Wait()
	var mp runtime.MemStats
	runtime.ReadMemStats(&mp)
	fmt.Printf("Before GC: %+v\n\n\n", mp)
	runtime.GC()
	runtime.ReadMemStats(&mp)
	fmt.Printf("After GC: %+v\n\n\n", mp)
}

func setfinalizer() {
	wg := new(sync.WaitGroup)
	finalizerWG := new(sync.WaitGroup)
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func() interface{} {
			defer wg.Done()
			tmp := make(map[string]int, 10000)
			finalizerWG.Add(1)
			runtime.SetFinalizer(&tmp, func(t *map[string]int) {
				defer finalizerWG.Done()
				fmt.Println("Finalizer has run!")
			})
			return tmp
		}()
	}
	wg.Wait()
	var mp runtime.MemStats
	runtime.ReadMemStats(&mp)
	fmt.Printf("Before GC: %+v\n\n\n", mp)

	runtime.GC()
	finalizerWG.Wait()
	runtime.ReadMemStats(&mp)
	fmt.Printf("After first GC: %+v\n\n\n", mp)

	runtime.GC()
	runtime.ReadMemStats(&mp)
	fmt.Printf("After second GC: %+v\n\n\n", mp)

}
