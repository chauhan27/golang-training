package main

func main() {
	// gc()
	// setfinalizer()
}

func gc() {

}

func setfinalizer() {

}
