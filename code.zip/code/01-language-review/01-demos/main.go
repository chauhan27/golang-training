package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

func main() {
	var wg sync.WaitGroup
	ch := make(chan string)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Microsecond)
	defer cancel()

	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(i int, wg *sync.WaitGroup, ctx context.Context) {
			if ctx.Err() != nil {
				return
			}
			ch <- fmt.Sprintf("Current counter value: %v\n", i)
			wg.Done()
			ctx2, cancel := context.WithCancel(ctx)
			go func(ctx context.Context) {

			}(ctx2)
		}(i, &wg, ctx)
	}
	go func() {
		wg.Wait()
		close(ch)
	}()

	for {
		select {
		case msg, ok := <-ch:
			if !ok {
				cancel()
				return
			}
			fmt.Println(msg)
		case <-ctx.Done():
			fmt.Println(ctx.Err())
			return
		}
	}

}
