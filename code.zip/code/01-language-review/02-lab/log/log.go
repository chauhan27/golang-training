package log

var (
	destination string
	lw          logWriter
)

func Run(dest string) {
}

type logWriter struct{}

func (logWriter) Write(msg []byte) (int, error) {
	return 0, nil
}
