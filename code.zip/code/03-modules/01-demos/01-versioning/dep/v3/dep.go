package dep

type User struct {
	UserID string
}
