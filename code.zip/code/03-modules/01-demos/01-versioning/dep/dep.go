package dep

type User struct {
	Username string
}
