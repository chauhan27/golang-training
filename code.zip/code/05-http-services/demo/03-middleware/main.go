package main

import (
	"compress/gzip"
	"fmt"
	"io"
	"net/http"
	"strings"
)

func main() {
	http.Handle("/admin", &authMiddleware{
		next: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Add("Content-Type", "text/html")
			fmt.Fprint(w, "Welcome to the admin page!")
		}),
	})

	http.ListenAndServe(":3000", &gzipMiddleware{next: nil})
}

type gzipMiddleware struct {
	next http.Handler
}

func (gm *gzipMiddleware) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if gm.next == nil {
		gm.next = http.DefaultServeMux
	}

	encodings := r.Header.Get("Accept-Encoding")
	if !strings.Contains(encodings, "gzip") {
		gm.next.ServeHTTP(w, r)
		return
	}
	w.Header().Add("Content-Encoding", "gzip")
	gzipwriter := gzip.NewWriter(w)
	defer gzipwriter.Close()
	grw := gzipResponseWriter{
		ResponseWriter: w,
		Writer:         gzipwriter,
	}
	gm.next.ServeHTTP(grw, r)
}

type gzipResponseWriter struct {
	http.ResponseWriter
	io.Writer
}

func (grw gzipResponseWriter) Write(data []byte) (int, error) {
	return grw.Writer.Write(data)
}

type authMiddleware struct {
	next http.Handler
}

func (amw *authMiddleware) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	credentials := r.Header.Get("Authentication")
	if len(credentials) == 0 {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	// defer in case primary handler wants to set headers, which must be set before body
	defer fmt.Fprintf(w, "\nCredentials: %v", credentials)
	amw.next.ServeHTTP(w, r)
}
