package main

import (
	"fmt"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

func main() {
	http.HandleFunc("/split/", parametricRoutesSplit)
	http.HandleFunc("/regexp/", parametricRoutesRegexp)

	http.ListenAndServe(":3000", nil)
}

// pattern /split/users/{:username}/roles/{:roleID}
func parametricRoutesSplit(w http.ResponseWriter, r *http.Request) {
	segments := strings.Split(r.URL.Path, "/")
	fmt.Println("segments: ", segments)
	if len(segments) != 6 {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	username := segments[2]
	roleIDRaw := segments[5]
	roleID, err := strconv.Atoi(roleIDRaw)
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		log.Println("Invalid roleID: ", roleIDRaw)
		return
	}
	w.Header().Add("content-type", "text/html")
	fmt.Fprintf(w, `
		<table>
			<tr>
				<td>Username</td><td>%v</td>
			</tr>
			<tr>
				<td>Role ID</td><td>%v</td>
			</tr>
		</table>
	`, username, roleID)
}

// pattern /regexp/users/{:username}/roles/{:roleID}
var pattern = regexp.MustCompile(`^\/regexp\/users\/(\S+?)\/roles\/(\d+?)$`)

func parametricRoutesRegexp(w http.ResponseWriter, r *http.Request) {
	matches := pattern.FindStringSubmatch(r.URL.Path)
	fmt.Println("matches: ", matches)
	if len(matches) == 0 {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	username := matches[1]
	roleIDRaw := matches[2]
	roleID, err := strconv.Atoi(roleIDRaw)
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		log.Println("Invalid roleID: ", roleIDRaw)
		return
	}
	w.Header().Add("content-type", "text/html")
	fmt.Fprintf(w, `
		<table>
			<tr>
				<td>Username</td><td>%v</td>
			</tr>
			<tr>
				<td>Role ID</td><td>%v</td>
			</tr>
		</table>
	`, username, roleID)
}
