package main

import (
	"fmt"
	"log"
	"net/http"
)

func main() {
	http.HandleFunc("/route", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Handler for /route"))
	})
	http.HandleFunc("/route/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Handler for /route/"))
	})

	http.Handle("/handler", &myHandler{})

	http.HandleFunc("/query", func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		w.Header().Add("content-type", "text/html")
		func() {
			w.Write([]byte("<table>"))
			defer w.Write([]byte("</table>"))
			for k, v := range params {
				w.Write([]byte(fmt.Sprintf("<tr><td>%v</td><td>%v</td></tr>", k, v)))
			}
		}()
	})
	log.Fatal(http.ListenAndServe(":3000", nil))
}

type myHandler struct{}

func (myHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("I implement the http.Handler interface!"))
}
