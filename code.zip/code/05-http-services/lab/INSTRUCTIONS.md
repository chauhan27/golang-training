# HTTP Services

Create a program that contains a route-specific middleware.

* The matched route should be of the form /users/{username}/roles/{roleID}
    * {username} and {roleID} are parametric and have not fixed value
    * the handler should return the username and roleID to the requester
* Create middleware for the above route that only allows the username "grogu" into the main handler, all other routes should receive a 401 - UNAUTHORIZED response
* Add a handler for the root route that returns a 404 - NOT FOUND response

BONUS:
* create a global middleware that logs the path of each request to the default logger
