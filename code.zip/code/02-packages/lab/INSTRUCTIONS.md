# Packages

The `main.go` file contains a simple RESTful API for a blogging service. Improve the organization of the program using packages. Make sure that packages are created following package-oriented design principles. Please note that the source code will need to be updated to ensure that the application continues to function. 
