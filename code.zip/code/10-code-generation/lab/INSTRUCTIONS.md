# Code Generation

Create a program that will generate a package with strongly typed `Add` functions of the form `f(A, B) -> A + B` (e.g. f(1, 2) -> 3).

* The function named should include the type: `AddInt`, `AddFloat32`, etc.
* The types to be generated should be passed into the program via a flag
* The destination package should also be passed in as a flag
* The generated code should include the standard comment: 
  * `// Code generated DO NOT EDIT`
* Create a test program that contains the correct directive to generate Add functions for complex64s and strings.
  * Specify the destination package to be `main` using code generation environment variables
* Test the program to ensure it functions as expected