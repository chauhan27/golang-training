package main

import "fmt"

//go:generate ../gen/gen -types=complex64,string -package=$GOPACKAGE
func main() {
	fmt.Println(AddComplex64(2+3i, 3+6i))
	fmt.Println(AddString("foo", "bar"))
}
